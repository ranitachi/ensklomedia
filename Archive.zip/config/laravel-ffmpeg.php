<?php

// 'default_disk' => '/Application/XAMPP/htdocs/ensiklomedia/public/uploadfiles/video/',
return [
    'default_disk' => 'public_dir',

    'ffmpeg.binaries' => '/usr/local/bin/ffmpeg',
    'ffmpeg.threads'  => 12,

    'ffprobe.binaries' => '/usr/local/bin/ffprobe',

    'timeout' => 3600,
];

<?php

return [
    'pattern' => env('LOGVIEWER_PATTERN', '*.log'),
];

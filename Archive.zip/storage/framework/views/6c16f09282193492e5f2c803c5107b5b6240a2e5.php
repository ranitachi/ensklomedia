<div class="col-md-12">
<table class="table table-bordered table-hover table-striped" width="100%">
    <thead>
        <tr>
            <th class="text-center">No</th>
            
            <th class="text-center">Wilayah</th>
            <th class="text-center">Lokasi</th>
            <th class="text-center">Tanggal Pelaksanaan</th>
            <th class="text-center">PIC Fasilitasi</th>
            <th class="text-center">Narsum/Reviewer</th>
            <th class="text-center" style="width:90px;">Aktif</th>
            <th class="text-center" style="width:70px;">Aksi</th>
        </tr>             
    </thead>
    <tbody>
<?php
    $no=$page+1;
?>
        <?php if(count($instrumen)==0): ?>
            <tr>
                <th colspan="7" class="text-center"><i>Data Kegiatan Fasilitas Belum Tersedia</i></th>
            </tr>
        <?php else: ?>
            
    <?php $__currentLoopData = $instrumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e(($no)); ?></td>
                <td class="text-left"><?php echo e(isset($v->provinsi->name) ? $v->provinsi->name : ''); ?></td>
                <td class="text-left"><?php echo e($v->nama_fasilitasi); ?></td>
                <td class="text-center"><b><?php echo e(date('d-m-Y', strtotime($v->start_date))); ?></b> <br>s.d. <br><b><?php echo e(date('d-m-Y', strtotime($v->end_date))); ?></b></td>
                <td class="text-left">
                <?php if(isset($mapping[$v->id])): ?>
                    <?php if(count($mapping[$v->id])!=0): ?>
                        <?php $__currentLoopData = $mapping[$v->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <i class="fa fa-close" data-toggle="tooltip" data-placement="right" title="Hapus PIC" style="color:red;cursor:pointer" onclick="hapuspic('<?php echo e($item->id); ?>')"></i>&nbsp;<b><?php echo e($item->user->email); ?></b><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>                    
                        <button class="btn btn-xs btn-info" onclick="pilihpic('<?php echo e($v->id); ?>')">
                            <i class="fa fa-search"></i> Pilih PIC
                        </button>
                    <?php endif; ?>
                <?php else: ?>
                    <button class="btn btn-xs btn-info" onclick="pilihpic('<?php echo e($v->id); ?>')">
                        <i class="fa fa-search"></i> Pilih PIC
                    </button>
                <?php endif; ?>
                </td>
                <td class="text-left">
                    <?php if(isset($narsum[$v->id])): ?>
                        <?php if(count($narsum[$v->id])!=0): ?>
                            <?php $__currentLoopData = $narsum[$v->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($item->narsum1->email)): ?>
                                    <i class="fa fa-close" data-toggle="tooltip" data-placement="right" title="Hapus PIC" style="color:red;cursor:pointer" onclick="hapusnarsum('<?php echo e($item->id); ?>',1)"></i>&nbsp;<b><?php echo e($item->narsum1->email); ?></b><br>
                                <?php endif; ?>

                                <?php if(isset($item->narsum2->email)): ?>
                                    <i class="fa fa-close" data-toggle="tooltip" data-placement="right" title="Hapus PIC" style="color:red;cursor:pointer" onclick="hapusnarsum('<?php echo e($item->id); ?>',2)"></i>&nbsp;<b><?php echo e($item->narsum2->email); ?></b><br>
                                <?php endif; ?>

                                <?php if(is_null($item->narsum_1_id) && is_null($item->narsum_2_id)): ?>
                                    <button class="btn btn-xs btn-info" onclick="pilihnarsum('<?php echo e($v->id); ?>')">
                                        <i class="fa fa-search"></i> Pilih Narsum
                                    </button>
                                <?php endif; ?>

                                <?php if($item->narsum_2_id==0): ?>
                                    <button class="btn btn-xs btn-info" onclick="pilihnarsum('<?php echo e($v->id); ?>')">
                                        <i class="fa fa-search"></i> Pilih Narsum
                                    </button>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>                    
                            <button class="btn btn-xs btn-info" onclick="pilihnarsum('<?php echo e($v->id); ?>')">
                                <i class="fa fa-search"></i> Pilih Narsum
                            </button>
                        <?php endif; ?>
                    <?php else: ?>
                        <button class="btn btn-xs btn-info" onclick="pilihnarsum('<?php echo e($v->id); ?>')">
                            <i class="fa fa-search"></i> Pilih Narsum
                        </button>
                        <button class="btn btn-xs btn-success" onclick="random('<?php echo e($v->id); ?>')">
                            <i class="fa fa-refresh"></i> Random Narsum
                        </button>
                    <?php endif; ?>
                    
                </td>
                <td class="text-center">
                    <?php echo ($v->flag==1 ? '<span class="label label-success">Aktif</span>' : '<span class="label label-danger">Non Aktif</span>'); ?>

                    
                    <?php if($v->flag==1): ?>
                        <span class="label label-danger" style="cursor:pointer" onclick="changestatus('<?php echo e($v->id); ?>','0')" data-toggle="tooltip" title="Non Aktifkan" data-placement="top"><i class="fa fa-times"></i></span>
                    <?php else: ?>
                        <span class="label label-primary" style="cursor:pointer" onclick="changestatus('<?php echo e($v->id); ?>','1')" data-toggle="tooltip" title="Aktifkan" data-placement="top"><i class="fa fa-check"></i></span>
                    <?php endif; ?>
                </td>
                <td class="text-center">
                    <a href="javascript:loadform('<?php echo e($v->id); ?>')" style="text-transform:capitalize !important;" class="btn btn-xs btn-success"><i class="fa fa-pencil"></i></a>
                    <a href="javascript:hapus('<?php echo e($v->id); ?>')" style="text-transform:capitalize !important;" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
                </td>
            </tr>
    <?php
        $no++;
    ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

</tbody>
</table>
<div style="text-align:center"><?php echo e($instrumen->links()); ?></div>
</div>
<table class="table table-bordered table-hover table-striped" width="100%">
    <thead>
        <tr>
            <th class="text-center">No</th>
            <th class="text-center">Pertanyaan</th>
            <th class="text-center">Jawaban</th>
        </tr>             
    </thead>
    
    <tbody>
        
            <tr>
                <td class="text-center"><?php echo e($no); ?></td>
                <td class="text-left"><?php echo e($soal[0]->test->question); ?></td>
                <td class="text-left">
                    <?php $__currentLoopData = $soal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row" style="margin-bottom:10px;">
                            <div class="col-md-1 text-right">
                                <?php if(isset($jwb[$item->id])): ?>
                                    <input type="radio" name="jawaban[<?php echo e($item->question_id); ?>]" onclick="jawabsoal('<?php echo e($jenis); ?>','<?php echo e($id); ?>',<?php echo e($no); ?>,<?php echo e($item->id); ?>,<?php echo e($idfasil); ?>)" checked="checked">
                                <?php else: ?>
                                    <input type="radio" name="jawaban[<?php echo e($item->question_id); ?>]" onclick="jawabsoal('<?php echo e($jenis); ?>','<?php echo e($id); ?>',<?php echo e($no); ?>,<?php echo e($item->id); ?>,<?php echo e($idfasil); ?>)">
                                <?php endif; ?>
                            </div>
                            <div class="col-md-11"><?php echo e($item->answer); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            </tr>
            
        
    </tbody>
</table>
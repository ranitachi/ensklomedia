<div class="col-md-12">
    <label>Tugas PIC</label>
    <select name="users__pic" class="form-control" data-placeholder="PIC">
        <option value="0"></option>
        <?php if($id!=-1): ?>
            <option value="1" <?php echo e($det->pic=='1' ? 'selected="selected"' : ''); ?>>Ya</option>
            <option value="0" <?php echo e($det->pic=='0' ? 'selected="selected"' : ''); ?>>Tidak</option>
        <?php else: ?>
            <option value="1">Ya</option>
            <option value="0">Tidak</option>
        <?php endif; ?>
    </select>
</div>
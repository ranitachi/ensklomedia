<?php if($idsaung!=-1): ?>
    <?php if(Auth::user()->id == $saung->created_user_id || Auth::user()->id == $saung->reviewer_id): ?>
        <div class="row">
            <div class="col-md-5">
                <div id="data-soal"></div>
                <div id="detail"></div>
            </div>
            <div class="col-md-7">
                <div id="form"></div>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-md-8">
                <div id="data"></div>
            </div>
            <div class="col-md-4">
                <div id="info"></div>
            </div>
        </div>   
    <?php endif; ?>
<?php else: ?>    
    <div class="row">
        <div class="col-md-12"><h1>Halaman Latihan Tidak Dapat Diakses</h1></div>
    </div>
<?php endif; ?>
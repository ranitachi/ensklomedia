<table class="table table-bordered table-hover table-striped" width="100%">
    <thead>
        <tr>
            <th class="text-center">No</th>
            <th class="text-left">Saung</th>
            <th class="text-center">Status Saung</th>
            <th class="text-center">Guru</th>
            <th class="text-center">Email</th>
            <th class="text-center" style="width:80px;">#</th>
        </tr>             
    </thead>
    <tbody>
    <?php $__currentLoopData = $saung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ii => $vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e(++$ii); ?></td>
            <td class="text-left"><?php echo e($vv->saung_name); ?></td>
            <td class="text-left"><?php echo $vv->flag==1 ? '<span class="label label-success">Aktif</span>' : '<span class="label label-warning">Tidak Aktif</span>'; ?></td>
            <td class="text-left"><?php echo e($vv->user->profile->name); ?></td>
            <td class="text-left"><?php echo e($vv->user->email); ?></td>
            <td class="text-center">
                <a href="<?php echo e(url('buka-saung/'.$vv->video->slug)); ?>" class="btn btn-xs btn-primary" target="_blank" data-toggle="tooltip" title="Lihat Saung"><i class="fa fa-search"></i></a>
                <a href="javascript:hapussaung('<?php echo e($vv->id); ?>','<?php echo e($vv->fasilitasi_id); ?>')" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Hapus Saung"><i class="fa fa-trash"></i></a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
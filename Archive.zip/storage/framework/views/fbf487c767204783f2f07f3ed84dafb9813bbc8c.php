<form method="POST" action="<?php echo e(url('evaluasi-simpan/'.$jenis.'/'.$idfasil)); ?>" class="form-horizontal" id="form-evaluasi-penyelenggara">
    <legend>Form Evaluasi Penyelenggaraan</legend>
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    
    <h4 style="margin-top:10px;">Petunjuk Pengisian	: 
        <ol style="margin-left:20px;">
            <li>Pilihlah salah satu poin  pada kolom  (kondisi nyata yang dirasakan) menurut pendapat bapak/ibu yang paling sesuai.
			<li>Kondisi nyata adalah apa yang dirasakan bapak/ibu terhadap pelayanan dan materi fasilitasi selama kegiatan berlangsung
			<li>Apabila ada saran untuk perbaikan dapat dituliskan pada kolom saran

        </ol>
    </h4>
    <table class="table table-bordered table-hover table-striped" width="100%">
        <thead>
            <tr>
                <th class="text-center" colspan="2">INDIKATOR</th>
                <th class="text-center" colspan="5">KONDISI YANG DISARANKAN</th>
                <th class="text-center">SARAN</th>
            </tr>             
        </thead>
        <tbody>
                <?php
                    $no=1;
                ?>
                <?php $__currentLoopData = $item[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $pilihan=explode('/',$v->pilihan);
                    ?>
                    <tr>
                        <td class="text-left" style="font-weight:bold;width:30px;font-size:10px;"><?php echo e($no); ?></td>
                        <td class="text-left" style="font-weight:bold;font-size:10px;"><?php echo e($v->indikator); ?></td>
                        <?php if(count($pilihan)>1): ?>
                            <?php $__currentLoopData = $pilihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ii): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                            <td class="text-center" style="font-weight:bold">
                                 <div style="height:35px;font-size:10px;"><?php echo e(str_replace('__','/',$ii)); ?></div>
                                <input type="radio" name="pilihan[<?php echo e($v->id); ?>]" value="<?php echo e($ii); ?>">
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <td class="text-center" colspan="5"></td>
                        <?php endif; ?>                        
                        <td class="text-center" style="font-size:10px;font-weight:bold">
                            <?php if(count($pilihan)>1): ?>
                                <textarea name="saran[<?php echo e($v->id); ?>]" style="height:35px" class="form-control"></textarea>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php if(isset($item[$v->id])): ?>
                        <?php
                            $x='a';
                        ?>
                        <?php $__currentLoopData = $item[$v->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php
                                $pilihan=explode('/',$it->pilihan);
                            ?>

                            <td class="text-right" style="font-size:10px;"><?php echo e($x); ?></td>
                            <td class="text-left" style="font-size:10px;"><?php echo e($it->indikator); ?></td>
                            <?php if(count($pilihan)>1): ?>
                                <?php $__currentLoopData = $pilihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ii): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                                <td class="text-center">
                                    <div style="height:35px;font-size:10px;"><?php echo e(str_replace('__','/',$ii)); ?></div>
                                    <input type="radio" name="pilihan[<?php echo e($it->id); ?>]" value="<?php echo e($ii); ?>">
                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <td class="text-center" colspan="5"></td>
                            <?php endif; ?>                        
                            <td class="text-center" style="font-size:10px;">
                                <?php if(count($pilihan)>1): ?>
                                    <textarea name="saran[<?php echo e($it->id); ?>]" style="height:35px" class="form-control"></textarea>
                                <?php endif; ?>
                            </td>
                            <?php
                                $x++;
                            ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php
                    $no++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            
        </tbody>
    </table>
    <button class="btn btn-md btn-success pull-right" type="button" onclick="endevaluasipenyelenggara('<?php echo e(ucwords($jenis)); ?>','<?php echo e($idfasil); ?>')"><i class="fa fa-save"></i> &nbsp;&nbsp;End Test</button>
</form>
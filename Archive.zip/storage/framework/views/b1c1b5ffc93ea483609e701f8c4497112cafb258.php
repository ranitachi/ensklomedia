<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($title); ?></title>

    <link href="<?php echo e(asset('css/videojs.css')); ?>" rel="stylesheet">
</head>
<body>

    <video id="example_video_1" class="video-js vjs-default-skin vjs-big-play-centered"
           controls preload="auto" height="600" width="980">

        <source src="<?php echo e(url($video)); ?>" type="<?php echo e($mime); ?>" />
    </video>

    <script src="<?php echo e(asset('js/videojs.js')); ?>"></script>

    <script>
        videojs(document.getElementById('example_video_1'), {}, function() {
            // This is functionally the same as the previous example.
        });
    </script>
</body>
</html>
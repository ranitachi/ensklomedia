<form class="form-horizontal" id="form-category" style="border:1px solid #aaa;padding:10px;">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<?php if($id!=-1): ?>
		<?php echo e(method_field('PATCH')); ?>

	<?php endif; ?>
    <div class="row">
        
        <div class="col-md-12">
            <label>Pertanyaan</label>
                 <textarea class="form-control" rows="4"  placeholder="Pertanyaan" name="pertanyaan"><?php echo e(($id!=-1 ? $det->pertanyaan : '')); ?></textarea>
        </div>
        <div class="col-md-12">
            <label>Bobot Nilai</label>
                 <input type="text" class="form-control"  placeholder="Bobot Niliai" name="bobot" value="<?php echo e(($id!=-1 ? $det->bobot : '')); ?>">
        </div>
        <div class="col-md-12">
            <label>Aktif</label>
            <select name="flag" class="form-control" data-placeholder="Aktif">
                <?php if($id==-1): ?>
                    <option value="1">Aktif</option>
                    <option value="0">Non Aktif</option>
                <?php else: ?>
                    <option value="1" <?php echo e($id==1 ? 'selected="selected"' : ''); ?>>Aktif</option>
                    <option value="0" <?php echo e($id==0 ? 'selected="selected"' : ''); ?>>Non Aktif</option>
                <?php endif; ?>
                
            </select>
        </div>

            <div class="col-md-6" style="padding-top:10px;">
                <button type="button" class="btn btn-sm btn-success" onclick="baru()"><i class="fa fa-new"></i>&nbsp;Data Baru</i></button>
            </div>
            <div class="col-md-6" style="padding-top:10px;">
                 <button type="button" class="btn btn-sm btn-primary pull-right" onclick="simpan(<?php echo e($id); ?>)"><i class="fa fa-save"></i>&nbsp;Simpan</i></button>
             </div>
         </div>
     </form>
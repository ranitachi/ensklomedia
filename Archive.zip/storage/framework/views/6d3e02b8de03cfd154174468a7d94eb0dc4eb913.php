<video id="example_video_1" controls preload="" style="width:100%;height:auto">
    <source src="<?php echo e($vid); ?>" type="<?php echo e($mime); ?>" />
</video>

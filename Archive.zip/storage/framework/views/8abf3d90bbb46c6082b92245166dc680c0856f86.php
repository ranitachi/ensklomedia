<form class="form-horizontal" id="form-tantangan">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <div class="row">
        
        <div class="col-md-12">
            <label>Topik Tantangan Lain</label>
            <input type="text" class="form-control" id="tantangan"  placeholder="Topik Tantangan Lain" name="tantangan" value="<?php echo e($id==-1 ? '' : $data->topik); ?>">
        </div>
        <div class="col-md-12">
            <label>Keterangan</label>
            <textarea class="form-control" rows="4"  placeholder="Keterangan" name="keterangan"><?php echo e($id==-1 ? '' : $data->penjelasan); ?></textarea>
        </div>
    </div>
</form>
<div class="col-md-12">
<table class="table table-bordered table-hover table-striped" width="100%">
    <thead>
        <tr>
            <th class="text-center">No</th>
            <th class="text-center">Kategori</th>
            <th class="text-center">Mata Pelajaran</th>
        </tr>             
    </thead>
    <tbody>
 <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e((++$i)); ?></td>
            <td class="text-left"><b><?php echo e(($v->name)); ?></b></td>
            <td class="text-left">
                <div class="row">
                    <div class="col-md-9">
                    <?php if(isset($petamateri[$v->id])): ?>
                        <?php $__currentLoopData = $petamateri[$v->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col-md-2 col-sm-1 col-xs-1" style="text-align:right;color:red;"><i class="fa fa-plus-circle" onclick="topikmateri('<?php echo e($v->id); ?>','<?php echo e($item->id); ?>','-1')" style="cursor:pointer"></i></div>
                                <div class="col-md-9 col-sm-9 col-xs-9">
                                    <a href="#">
                                        <b><?php echo e($item->title); ?></b>
                                    </a>
                                    <?php if(isset($topik[$item->id])): ?>
                                        <ul style="margin-left:20px;list-style:none;margin-top:5px;" class="ul-m">
                                            <?php $__currentLoopData = $topik[$item->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <i class="fa fa-edit" onclick="topikmateri('<?php echo e($v->id); ?>','<?php echo e($item->id); ?>',<?php echo e($itm->id); ?>)" style="cursor:pointer;color:blue;"></i> 
                                                    <i class="fa fa-trash" onclick="hapustopikmateri('<?php echo e($v->id); ?>','<?php echo e($item->id); ?>',<?php echo e($itm->id); ?>)" style="cursor:pointer;color:red;"></i> 
                                                    <?php echo e($itm->title); ?>

                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <i>Mata Pelajaran Masih Kosong</i>
                    <?php endif; ?>    
                    </div>
                    
                </div>
            </td>
            
        </tr>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
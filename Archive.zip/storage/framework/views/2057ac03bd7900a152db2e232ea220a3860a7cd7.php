<?php $__env->startSection('title'); ?>
    <title>Category - Ensiklomedia</title>
    <style>
        .share-in {
            margin-top: 0px !important;
        }

        .custom-size {
            height: 118px;
            width: 208px;
        }

        .thumb {
            height: 150px;
            background: url("<?php echo e(asset('assets/img/no-image-02.png')); ?>");
            background-size: 95% 100%;
            background-position: center;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $first_letter=substr($category_name,0,1);
    ?>
        <!-- Category Cover Image -->
        <div id="category-cover-image" class="hidden-sm hidden-xs">
            <div class="image-in">
                <img src="<?php echo e(asset('assets/demo_img/category-img.jpg')); ?>" style="width:100%;height:150px;" alt="">
            </div>
            <h1 class="title"> <span data-letters="<?php echo e($first_letter); ?>"></span>&nbsp;<?php echo e($category_name); ?></h1>
            <ul class="category-info">
                
            </ul>
        </div>
        <!-- // Category Cover Image -->
        <div class="hidden-lg hidden-md" style="margin-top:10px;">&nbsp;</div>
        <!-- category -->
        <div id="category">
            <div class="row">
                <div class="col-md-2 hidden-sm hidden-xs">
                    <div class="share-in">
                        <h1 class="title">Mata Pelajaran</h1>
                        <ul class="social-link">
                          <?php if(count($mapel)!=0): ?>
                              <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="google-plus"><a href="#"> <?php echo e($item->title); ?> </a></li>  
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>  
                            
                        </ul>
                        <br><br>
                        
                    </div>

                </div><!-- // col-md-2 -->

                <div class="col-md-10 col-xs-12 col-sm-12">
                    
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            
                            <div class="row">
                                    
                            <?php $__currentLoopData = $videos->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $waktu=$video->created_at->diffForHumans();
                                        $wkt=text_translate($waktu,'en','id');
                                        
                                        $durasi='00:00';
                                        if($video->duration!='00:00:00')
                                            {
                                                if($video->duration!=-1)
                                                {
                                                    if(strtok($video->duration,':')=='00')
                                                    {
                                                        $durasi=substr($video->duration,3,5);
                                                    }
                                                    else
                                                        $durasi=$video->duration;
                                                }
                                                else if($video->duration==0)
                                                {
                                                    $durasi="00:00";
                                                }
                                                else {
                                                    $durasi="00:00";
                                                }
                                            }
                                            else {
                                                
                                                $durasi="00:00";
                                            }
                                    ?>
                                        <?php if($durasi!='00:00'): ?>
                                            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6 margin-left-right-2 col-custom">
                                                <div class="video-item">
                                                    <div class="thumb" style="background:url(assets/img/no-image-02.png);background-size:90% 100%;background-position:center;border:1px solid #ccc;"> 
                                                        <div class="hover-efect"></div>
                                                        <small class="time"><?php echo e($durasi); ?></small>
                                                        <?php

                                                            $cover = "http://ensiklomedia.tve.kemdikbud.go.id/uploadfiles/image/".$video->image_path;
                                                            if (File::exists(public_path().'/uploadfiles/image/'.$video->image_path)) {
                                                                $cover = url('uploadfiles/image/'.$video->image_path);
                                                            }
                                                            else
                                                            {
                                                                $cv='assets/img/no-image-02.png';
                                                                $cover=url($cv);
                                                            }
                                                        ?>
                                                        <a href="<?php echo e(route('watch', $video->slug)); ?>" onclick="addhit('<?php echo e($video->id); ?>')"><img class="custom-size" src="<?php echo e($cover); ?>" alt=""></a>
                                                    </div>
                                                    <div class="video-info">
                                                        <a href="<?php echo e(route('watch', $video->slug)); ?>" class="title"><?php echo e(ucwords(strtolower($video->title))); ?></a>
                                                        <a class="channel-name" href="#" onclick="addhit('<?php echo e($video->id); ?>')"><?php echo e($category_name); ?>    </a>
                                                        <span class="views"><i class="fa fa-eye"></i><?php echo e($video->hit); ?> views </span>
                                                        <span class="date"><i class="fa fa-clock-o"></i><?php echo e($wkt); ?> </span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div><!-- // row -->

                        </div>
                        
                    <!-- Loading More Videos -->
                    
                    <!-- // Loading More Videos -->

                </div>
            </div><!-- // row -->
        </div>
        <!-- // category -->

   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footscript'); ?>
    <script>
        function addhit(id)
        {
            $.ajax({
                url : APP_URL+'/video-add-hit/'+id,
                success : function(a){
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
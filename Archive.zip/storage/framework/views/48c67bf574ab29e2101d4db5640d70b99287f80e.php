<?php $__env->startSection('title'); ?>
    <title>Kegiatan Fasilitasi - Ensiklomedia</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
             <div id="category" style="margin-top:20px;">
            	<div class="row">
                    
                    <div class="col-md-12">
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success">
                                <strong>Sukses!</strong> 
                                <?php echo e(Session::get('message')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-5">
                        
                        <div class="row">
                            <div class="col-md-12" >
                                <h1 class="new-video-title"> Informasi Kegiatan Fasilitasi</h1>
                            </div>
                        </div>
                        <div class="row" id="data">
                            
                            <div class="col-md-4">Lokasi Kegiatan</div>
                            <div class="col-md-8">:&nbsp;&nbsp;<b><?php echo e($fas->provinsi->name); ?></b></div>
                            <div class="col-md-4">Waktu Kegiatan</div>
                            <div class="col-md-8">:&nbsp;&nbsp;<b><?php echo e(date('d-m-Y',strtotime($fas->start_date))); ?></b> s.d. <b><?php echo e(date('d-m-Y',strtotime($fas->end_date))); ?></b></div>
                            
                        </div><!-- // row -->


                        <!-- Loading More Videos -->
                        <div id="loading-more">
                            
                        </div>
                        <!-- // Loading More Videos -->

                    </div>
                    <div class="col-md-5">
                        <div class="row">
                            <div class="col-md-12">
                                <h1 class="new-video-title"><i class="fa fa-files-o"></i>  Kegiatan Fasilitasi</h1>
                            </div>
                           
                        </div>
                        <div id="form">
                            <table class="table table-bordered table-hover table-striped" width="100%">
                                <thead>
                                    <tr>
                                        <th class="text-center">No</th>
                                        <th class="text-center">Keterangan</th>
                                        <th class="text-center">Status</th>
                                        <th class="text-center" style="width:70px;">Aksi</th>
                                    </tr>             
                                </thead>
                                <tbody>
                                    <?php
                                        $no=1;
                                    ?>
                                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $st_menu=1;
                                    if($item->title=='Form Biodata')
                                    {
                                        if(count($pes_fas)!=0)
                                        {
                                            if($pes_fas->flag==1)
                                            {
                                                $status='<span class="label label-success">Sudah Di Verifikasi</span>';
                                            }
                                            else {
                                                $status='<span class="label label-primary">Belum Di Verifikasi</span>';
                                            }
                                        }
                                        else {
                                            $status='<span class="label label-warning">Belum Terdaftar</span>';
                                        }
                                    }
                                    else if(strpos($item->title,'Test')!==false)
                                    {
                                        if(count($pes_fas)!=0)
                                        {
                                            if($pes_fas->flag==1)
                                            {
                                                $status='<span class="label label-success">Sudah Bisa Mengikuti Test</span>';
                                            }
                                            else 
                                            {
                                                $status='<span class="label label-primary">Belum Bisa Mengikuti Tes</span>';
                                            }
                                        }
                                        else {
                                            $status='<span class="label label-warning">Belum Bisa Mengikuti Test</span>';
                                        }

                                        if(strpos($item->title,'Pre')!==false)
                                        {
                                            $ceknilai=\App\Model\Nilaitespeserta::where('fasilitasi_id',$fas->id)->where('user_id',Auth::user()->id)->where('jenis','=','pre')->first();
                                            if(count($ceknilai)!=0)
                                            {
                                                $status='<span class="label" style="background-color:darkblue">Nilai Pretest Anda : '.$ceknilai->nilai.'</span>';
                                            }
                                        }
                                        else if(strpos($item->title,'Post')!==false)
                                        {
                                            $ceknilai=\App\Model\Nilaitespeserta::where('fasilitasi_id',$fas->id)->where('user_id',Auth::user()->id)->where('jenis','=','post')->first();
                                            if(count($ceknilai)!=0)
                                            {
                                                $status='<span class="label" style="background-color:darkblue">Nilai Posttest Anda : '.$ceknilai->nilai.'</span>';
                                            }
                                        }

                                    }
                                    else if(strpos($item->title,'Penilaian')!==false)
                                    {
                                        if(count($pes_fas)!=0)
                                        {
                                            if($pes_fas->flag==1)
                                            {
                                                $status='<span class="label label-success">Sudah Dapat Mengisi Penilaian</span>';
                                            }
                                            else {
                                                $status='<span class="label label-primary">Belum Dapat Mengisi Penilaian</span>';
                                            }
                                        }
                                        else {
                                            $status='<span class="label label-warning">Belum Diaktivasi</span>';
                                        }
                                    }
                                    else {
                                        $status='<span class="label label-warning">Belum Bisa Terdaftar</span>';
                                    }

                                    if(isset($menu_pivot[$item->id]))
                                    {
                                        if($menu_pivot[$item->id]->flag!=1)
                                        {
                                            $status='<span class="label label-warning">Menu Belum Diaktifkan Oleh PIC</span>';
                                            $st_menu=0;
                                        }
                                    }
                                    else
                                    {
                                        $st_menu=0;
                                        $status='<span class="label label-warning">Menu Belum Diaktifkan Oleh PIC</span>';
                                    }
                                    
                                ?>
                                    <?php if($item->route!='cetak-sertifikat'): ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($no); ?></td>
                                        <td class="text-left"><?php echo e($item->title); ?></td>
                                        <td class="text-center"><?php echo $status; ?></td>
                                        <td class="text-center" style="width:70px;">
                                            <?php if($st_menu!=0): ?>
                                                
                                                <a href="<?php echo e(url($item->route.'/'.$iduser.'/'.$idfasil)); ?>" class="btn btn-xs btn-primary">
                                                    <i class="fa fa-toggle-right"></i> Klik
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php
                                        $no++;
                                    ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div><!-- // row -->
            </div>

		
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footscript'); ?>
    <script>
        $(document).ready(function(){
            //loaddata(-1);
            loadform(-1);
            
        });
        
        var currentLocation = window.location;
        
    </script>
<?php $__env->stopSection(); ?>

 <style>
    .chosen-container
    {
        width:100% !important;
    }
    th,td
    {
        font-size:12px !important;
        font-weight:200;
    }
    span.label
    {
        font-size:11px !important;
    }
</style>
<?php echo $__env->make('layouts.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
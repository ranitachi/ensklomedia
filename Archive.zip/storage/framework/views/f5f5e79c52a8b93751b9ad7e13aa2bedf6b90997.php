<div class="col-md-12">
<table class="table table-bordered table-hover table-striped" width="100%">
    <thead>
        <tr>
            <th rowspan="2" class="text-center">No</th>
            
            <th rowspan="2" class="text-center">Lokasi</th>
            <th rowspan="2" class="text-center">Waktu Pelaksaaan</th>
            <th colspan="<?php echo e(count($menu)+1); ?>" class="text-center">Menu</th>
            <th rowspan="2" class="text-center">Peserta</th>
            <th rowspan="2" class="text-center">Tambah Peserta</th>
            
        </tr>             
        <tr>
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th class="text-center"><?php echo str_replace('dan','<br>dan',$v->title); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>             
    </thead>
    <tbody>
<?php
    $no=$page+1;
    $iduser=Auth::user()->id;
?>
        
 <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <?php if(isset($map[$iduser][$v->wilayah_id][$v->id])): ?>
    
        <tr>
            <td class="text-center"><?php echo e(($no)); ?></td>
            
            <td class="text-left"><?php echo e(($v->provinsi->name)); ?></td>
            <td class="text-center">
                <b><?php echo e(date('d-m-Y', strtotime($v->start_date))); ?></b><br>s.d.<br>
                <b><?php echo e(date('d-m-Y', strtotime($v->end_date))); ?></b>
            </td>
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ii => $vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($vv->route=='cetak-sertifikat'): ?>
                <td class="text-center">
                    <a class="btn btn-xs btn-primary" href="<?php echo e(url($vv->route)); ?>/<?php echo e($v->id); ?>"><i class="fa fa-print"></i> <?php echo e($vv->title); ?></a>
                </td>
            <?php else: ?>
                <td class="text-center" style="width:120px;">
                    <?php if(isset($menupivot[$vv->id][$v->id])): ?>  
                        <?php
                            $det=$menupivot[$vv->id][$v->id];
                        ?>                  
                        <?php echo ($det->flag==1 ? '<span class="label label-success">Aktif</span>' : '<span class="label label-danger">Non Aktif</span>'); ?>    
                        <?php if($det->flag==1): ?>
                            <span class="label label-danger" style="cursor:pointer" onclick="changestatus('<?php echo e($v->id); ?>','<?php echo e($det->menu_id); ?>','0')" data-toggle="tooltip" title="Non Aktifkan" data-placement="top"><i class="fa fa-times"></i></span>
                        <?php else: ?>
                            <span class="label label-primary" style="cursor:pointer" onclick="changestatus('<?php echo e($v->id); ?>','<?php echo e($det->menu_id); ?>','1')" data-toggle="tooltip" title="Aktifkan" data-placement="top"><i class="fa fa-check"></i></span>
                        <?php endif; ?>
                    <?php else: ?>
                    <span class="label label-danger">Non Aktif</span>
                        <span class="label label-primary" style="cursor:pointer" onclick="changestatus('<?php echo e($v->id); ?>','<?php echo e($vv->id); ?>','1')" data-toggle="tooltip" title="Aktifkan" data-placement="top"><i class="fa fa-check"></i></span>
                    <?php endif; ?>
                </td>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <td class="text-center">
                <a href="javascript:lihatsaung('<?php echo e($v->id); ?>')" class="btn btn-xs btn-primary">
                    <i class="fa fa-search"></i> Lihat Saung
                </a>
            </td>
           <td style="width:350px;">

            <?php if(!isset($psrt[$v->id])): ?>
                 <i>Peserta Belum Ada</i>
            <?php else: ?>
                <?php if(count($psrt[$v->id])==0): ?>
                    <i>Peserta Belum Ada</i>
                
                <?php else: ?>
                    <?php $__currentLoopData = $psrt[$v->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row" style="margin-bottom:10px;">
                            <?php if($item->flag==0): ?>
                               
                                <div class="col-md-12" style="color:red" data-toggle="tooltip" title="Peserta Belum Aktif">
                                    <i class="fa fa-check" style="color:green;cursor:pointer" data-toggle="tooltip" title="Aktifkan Peserta" onclick="aktifkanpeserta('<?php echo e($item->idpf); ?>','1')"></i>
                                    <i class="fa fa-trash" style="color:red;cursor:pointer" data-toggle="tooltip" title="Hapus Peserta" onclick="hapuspeserta('<?php echo e($item->idpf); ?>')"></i>
                                    <b><?php echo e($item->name=='n/a'||$item->name=='' ? $item->user->email : $item->name); ?></b></div>
                            <?php else: ?>
                                <?php
                                    if(isset($nilai[$item->user_id]['pre']))
                                        $n_pre=$nilai[$item->user_id]['pre'];
                                    else
                                        $n_pre=0;

                                    if(isset($nilai[$item->user_id]['post']))
                                        $n_post=$nilai[$item->user_id]['post'];
                                    else
                                        $n_post=0;
                                ?>
                                <div class="col-md-12" style="color:green">
                                    <div style="margin-bottom:5px;">
                                        <i class="fa fa-close" style="color:purple;cursor:pointer" data-toggle="tooltip" title="Non Aktifkan Peserta" onclick="aktifkanpeserta('<?php echo e($item->idpf); ?>','0')"></i>
                                        <i class="fa fa-trash" style="color:red;cursor:pointer" data-toggle="tooltip" title="Hapus Peserta" onclick="hapuspeserta('<?php echo e($item->idpf); ?>')"></i>
                                        &nbsp;&nbsp;

                                        <a href="javascript:lihatbiodata('<?php echo e($item->idpf); ?>','<?php echo e($v->id); ?>')" target="_blank" data-toggle="tooltip" title="Bidata Peserta"><i class="fa fa-user" style="color:blue;cursor:pointer" ></i></a>
                                        <a href="<?php echo e(url('pre-test/'.$item->user_id.'/'.$v->id)); ?>" target="_blank" data-toggle="tooltip" title="Hasil Pre Test" ><span class="label label-primary" style="border-radius:15px"><?php echo e($n_pre); ?></span></a>
                                        <a href="<?php echo e(url('post-test/'.$item->user_id.'/'.$v->id)); ?>" target="_blank" data-toggle="tooltip" title="Hasil Post Test"><span class="label label-success" style="border-radius:15px"><?php echo e($n_post); ?></span></a><br>
                                    </div>
                                    <b><div class="label label-success" style="font-size:12px;margin-top:10px;" data-toggle="tooltip" title="<?php echo e($item->user->email); ?>"><?php echo e($item->name=='n/a'||$item->name=='' ? $item->user->email : ucwords(strtolower($item->name))); ?></div></b></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endif; ?>
                    
           </td>
           <td style="width:70px;">
               <div class="row">
                        <div class="col-md-10" style="color:green"><b><span class="label label-primary" style="font-size:12px;cursor:pointer;" onclick="addpeserta('<?php echo e($v->id); ?>')"><i class="fa fa-plus-square" style="cursor:pointer" data-toggle="tooltip" title="Tambah Peserta Fasilitasi" ></i> Tambah Peserta </span></b></div>
                    </div>
           </td>
        </tr>
        <?php
            $no++;
        ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>

<form class="form-horizontal" id="form-category" style="border:1px solid #aaa;padding:10px;">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	
    <div class="row">
        <div class="col-md-12">
            <label>Topik</label>
            <input type="text" class="form-control" placeholder="Topik" name="title" value="<?php echo e(($id!=-1 ? $det->title : '')); ?>">
        </div>
        <div class="col-md-12">
            <label>Judul Kategori</label>
            <select class="form-control" placeholder="Judul Kategori" name="category_id">
                <option value="">-Nama Kategori-</option>
                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($id!=-1): ?>
                        <?php if($item->id==$det->category_id): ?>
                            <option value="<?php echo e($det->category_id); ?>" selected="selected"><?php echo e($det->category->name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endif; ?>        
                    <?php else: ?>
                        <option value="<?php echo e($item->id); ?>" selected="selected"><?php echo e($item->name); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-12">
            <label>Mata Pelajaran</label>
            <select class="form-control" placeholder="Mata Pelajaran" name="mapel_id">
                <option value="">-MataPelajaran-</option>
                <?php $__currentLoopData = $petamateri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($id!=-1): ?>
                        <?php if($item->id==$det->mapel_id): ?>
                            <option value="<?php echo e($det->mapel_id); ?>" selected="selected"><?php echo e($det->mapel->title); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                        <?php endif; ?>        
                    <?php else: ?>
                        <option value="<?php echo e($item->id); ?>" selected="selected"><?php echo e($item->title); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-12">
            <label>Deskripsi</label>
                 <textarea class="form-control" rows="4"  placeholder="Deskripsi" name="desc"><?php echo e(($id!=-1 ? $det->desc : '')); ?></textarea>
        </div>

            <div class="col-md-9">&nbsp;</div>
            <div class="col-md-3" style="padding-top:10px;">
                 <button type="button" class="btn btn-sm btn-primary pull-right" onclick="simpan(<?php echo e($id); ?>)"><i class="fa fa-save"></i>&nbsp;Simpan</i></button>
             </div>
         </div>
     </form>
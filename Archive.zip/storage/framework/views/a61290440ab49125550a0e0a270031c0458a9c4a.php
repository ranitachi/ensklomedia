<?php if(count($data)!=0): ?>
    <a class="title" href="#"><?php echo e($data->topik); ?></a>
    <br>
    <?php echo $data->penjelasan; ?>

<?php else: ?>

    <h2>Topik Turunan Belum Memiliki Penjelasan</h2>
<?php endif; ?>
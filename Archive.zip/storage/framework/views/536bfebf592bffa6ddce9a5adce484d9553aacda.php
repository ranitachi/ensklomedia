<?php $__env->startSection('title'); ?>
    <title>Mapping Admin - Ensiklomedia</title>
    <style>
        th
        {
            text-align:center;
            background:#eee;
            border:1px solid #111;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div id="modalConfirm" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h5 class="modal-title">Information</h5>
                </div>

                <form action="<?php echo e(route('mapping-to-reviewer.store')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                            <div class="form-group">
                                <label for="">Silahkan pilih reviewer di bawah ini:</label>
                                <input type="hidden" id="vid" name="video_id">
                                <select name="id_reviewer" id="" class="form-control chosen-select">
                                    <option value="">-- Pilih --</option>
                                    <?php $__currentLoopData = $reviewers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->profile->name); ?> [<?php echo e($item->email); ?>]</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-close"></i>&nbsp;Tutup</button>
                        <button type="submit" class="btn btn-success" id="ok"><i class="fa fa-save"></i>&nbsp;Simpan</button>
                    </div>
                </form>                
            </div>
        </div>
    </div>

    <div id="category" style="margin-top:20px;">
        <div class="row">
            <div class="col-md-12">
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success">
                        <strong>Sukses!</strong> 
                        <?php echo e(Session::get('message')); ?>

                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-6" >
                        <h1 class="new-video-title"><i class="fa fa-users"></i> Mapping Video To Reviewer</h1>
                    </div>
                    <div class="col-md-6" style="padding-top:20px;">
                        
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8">
                        
                    </div>
                    <div class="col-md-4">
                        <div class="pull-right">
                            <div class="input-group">
                                <input type="text" class="form-control" id="video-search" placeholder="Cari Judul Video">
                                <div class="input-group-btn">
                                <button class="btn btn-primary" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-top:10px;">
                    <div class="col-md-12" >
                        
                        <div id="data">
                            <?php echo $__env->make('pages-admin.mapping-video.data', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div>
                </div>

                
                <!-- Loading More Videos -->
                

            </div>
            
        </div><!-- // row -->
    </div>		
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footscript'); ?>
    <script>
        function pilihreviewer(id)
        {
            $('#vid').val(id);
            $('#modalConfirm').modal('show');
            // $('.simpan').click(function(){
            //     var a = $(this).data('value')
            //     $('#vid').attr('value', a)
            // })
        }
        $('#video-search').on('keyup',function(){
            var value=$(this).val();
            $.ajax({
                    type : 'get',
                    url : APP_URL+'/search-video-reviewer',
                    data:{'search':value},
                    success:function(data){
                        $('div#data').html(data);
                    }
            });
        });

        $('body').on('click', '.pagination a', function(e) {
                e.preventDefault();
                //$('#load a').css('color', '#dfecf6');
                //$('#load').append('<img style="position: absolute; left: 0; top: 0; z-index: 100000;" src="/images/loading.gif" />');
                var url = $(this).attr('href');
                getPosts(url);
                window.history.pushState("", "", url);
        });
        function getPosts(page) {
            $.ajax({
                    url : page
                }).done(function (data) {
                    $('div#data').html(data);
                }).fail(function () {
                    alert('Halaman Data Video Tidak Dapat Di Tampilkan');
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<style>
    .chosen-container
    {
        width:100% !important;
    }
    th,td
    {
        font-size:14px !important;
        font-weight:200;
    }
</style>
<?php echo $__env->make('layouts.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title'); ?>
    <title>Form Super User - Ensiklomedia</title>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/pretify.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap-duallistbox.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
             <div id="category" style="margin-top:20px;">
            	<div class="row">
                    
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-6" >
                                <h1 class="new-video-title"><i class="fa fa-users"></i> Form <?php echo e($id==-1 ? 'Tambah' : 'Edit'); ?> Super User</h1>
                            </div>
                            <div class="col-md-6" style="padding-top:20px;">
                                
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-8">&nbsp;</div>
                            <div class="col-md-4">
                                <div class="pull-right">
                                    <a href="<?php echo e(url('mapping-super-user')); ?>" class="btn btn-danger">
                                        <i class="fa fa-angle-double-left"></i> Kembali
                                    </a>
                                </div>
                            </div>
                        </div>
                        <form id="add-admin" action="<?php echo e($id==-1 ? URL::to('mapping-super-user') : URL::to('mapping-super-user/'.$id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php if($id!=-1): ?>
								<?php echo e(method_field('PATCH')); ?>

                            <?php endif; ?>
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="row" style="margin-top:10px;" id="">
                                <div class="col-md-12" >
                                        <select multiple="multiple" size="10" id="duallistbox_demo1" name="nama_super_user[]">
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($v->authorization_level==2): ?>
                                                    <option value="<?php echo e($v->user_id.'__'.$v->name); ?>" selected="selected">[<?php echo e($v->email); ?>] - <?php echo e(is_null($v->name) ? 'n/a' : $v->name); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($v->user_id.'__'.$v->name); ?>">[<?php echo e($v->email); ?>] - <?php echo e(is_null($v->name) ? 'n/a' : $v->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <br>
                                        <button type="submit" class="btn btn-default btn-block">Simpan Mapping Super User</button>
                                   
                                </div>
                            </form>


                        <!-- Loading More Videos -->
                        <div id="loading-more">
                            
                        </div>
                        <!-- // Loading More Videos -->

                    </div>
                    
                </div><!-- // row -->
            </div>

		
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footscript'); ?>
    <script src="<?php echo e(asset('assets/js/pretify.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.bootstrap-duallistbox.js')); ?>"></script>
    <script>
        $(document).ready(function(){
           
        });
        var demo1 = $('select[name="nama_super_user[]"]').bootstrapDualListbox({
            filterTextClear : 'Tampilkan Semua',
            infoText : 'Semua Data'
        });
        
        $("#add-admin").submit(function() {
            //alert($('#duallistbox_demo1').val());
            var sv=$('#duallistbox_demo1').val();
            if(sv=='')
            {
                alert('Silahkan Pilih Pengguna yang akan dijadikan Super User')
                return false;
            }
            else
            {
                return true;
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
		
        	<div class="left-sidebar">
            	<div id="sidebar-stick">
            	<ul class="menu-sidebar" style="border-bottom:1px solid #dddddd;">
					<li><a href="<?php echo e(URL::to('/')); ?>"><i class="fa fa-home"></i>Home</a></li>
					<?php if(Auth::check()): ?>
						<li><a href="<?php echo e(URL::to('data-video')); ?>"><i class="fa fa-youtube-play"></i>Video Saya</a></li>	
					<?php endif; ?>
                	<li><a href="<?php echo e(URL::to('upload')); ?>"><i class="fa fa-star"></i>Trending</a></li>
				</ul>
            	<ul class="menu-sidebar accordion" id="accordion1">
					<li class="a-panel">
						<a data-toggle="collapse" data-parent="#accordion1" href="#firstLink" style="font-size:17px;font-weight:bold;">
							<div class="row">
								<div class="col-lg-9 col-md-9">
									KATEGORI
								</div>
								<div class="col-lg-1 col-md-1">
									<i class="fa fa-toggle-down"></i>
								</div>
								<div class="col-lg-2 col-md-2 pull-right">&nbsp;</div>
							</div>
						</a>
					</li>
					<?php
						$cat=App\Model\Category::orderBy('name')->get();
						$x=0;
					?>
					<ul id="firstLink" class="collapse">
					<?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
						$ln=strlen($v->name);
						if($ln>24)
							$cat_name=substr($v->name,0,24).' ...';
						else
							$cat_name=$v->name;

						$first_letter = substr($v->name,0,1);
						$x++;
					?>
						<li class="color-1">
							<a href="<?php echo e(route('video.bycategory', $v->slug)); ?>"><span data-letters="<?php echo e($first_letter); ?>"><?php echo e($cat_name); ?></span></a>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					<div class="text-center">&copy; Ensiklomedia 2018</div>
                </ul>
            	<!--<ul class="menu-sidebar">
                	<li><a href="#"><i class="fa fa-gear"></i>Settings</a></li>
                	<li><a href="#"><i class="fa fa-question-circle"></i>Help</a></li>
                	<li><a href="#"><i class="fa fa-send-o"></i>Send feedback</a></li>
                </ul>-->
				</div><!-- // sidebar-stick -->
                <div class="clear"></div>
            </div><!-- // left-sidebar -->
        

<ul class="list-topik">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <div class="row">
                <div class="col-md-9">
                    <?php if(isset($peserta_ttg[$i->id])): ?>
                        <a href="#" data-toggle="tooltip" title="Topik Ini Sudah Di Ikuti Oleh Siswa Lain" style="color:red;"><?php echo e($i->topik); ?></a>
                    <?php else: ?>
                        <?php echo e($i->topik); ?>

                    <?php endif; ?>
                </div>
                <div class="col-md-3">
                    <?php if(Auth::user()->id == $i->saung->created_user_id || Auth::user()->id == $i->saung->fasilitasi_id || Auth::user()->id == $i->saung->reviewer_id): ?>
                        <button class="btn btn-xs btn-primary" onclick="addtopiktantangan('<?php echo e($i->saung_id); ?>','<?php echo e($i->id); ?>','<?php echo e($i->user_created_id); ?>')"><i class="fa fa-pencil"></i></button>
                        <button class="btn btn-xs btn-danger" onclick="hapustantangan('<?php echo e($i->saung_id); ?>','<?php echo e($i->id); ?>','<?php echo e($i->user_created_id); ?>')"><i class="fa fa-trash"></i></button>
                    <?php else: ?>
                        <?php if(!isset($peserta_ttg[$i->id])): ?>
                            <button class="btn btn-xs btn-danger" data-toggle="tooltip" title="Ikut Tantangan" onclick="ikuttantangan('<?php echo e($i->saung_id); ?>','<?php echo e($i->video_id); ?>','<?php echo e($i->id); ?>')"><i class="fa fa-check-square-o"></i></button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div> 
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
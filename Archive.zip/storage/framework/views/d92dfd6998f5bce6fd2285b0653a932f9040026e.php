<script>
    let lastCheck = new Date();
    const caffeineSendDrip = function () {
        const ajax = window.XMLHttpRequest
            ? new XMLHttpRequest
            : new ActiveXObject('Microsoft.XMLHTTP');

        ajax.onreadystatechange = function () {
            if (ajax.readyState === 4 && ajax.status === 204) {
                lastCheck = new Date();
            }
        };

        ajax.open('GET', '<?php echo e($url); ?>');
        ajax.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        ajax.send();
    }

    setInterval(function () {
        caffeineSendDrip();
    }, <?php echo e($interval); ?>);

    if (<?php echo e($ageCheckInterval); ?> > 0) {
        setInterval(function () {
            if (new Date() - lastCheck >= <?php echo e($ageCheckInterval + $ageThreshold); ?>) {
                location.reload(true);
            }
        }, <?php echo e($ageCheckInterval); ?>);
    }
</script>

<ul class="list-topik">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <div class="row">
                <div class="col-md-9" onclick="penjelasan('<?php echo e($i->id); ?>')">
                    <?php echo e($i->topik); ?>

                </div>
                <div class="col-md-3">
                    <?php if(Auth::user()->id == $i->saung->fasilitasi_id || Auth::user()->id == $i->saung->reviewer_id): ?>
                        <button class="btn btn-xs btn-primary" onclick="tambahtopik('<?php echo e($i->video_id); ?>','<?php echo e($i->id); ?>','<?php echo e($i->user_created_id); ?>')"><i class="fa fa-pencil"></i></button>
                        <button class="btn btn-xs btn-danger" onclick="hapustopik('<?php echo e($i->video_id); ?>','<?php echo e($i->id); ?>','<?php echo e($i->user_created_id); ?>')"><i class="fa fa-trash"></i></button>
                    <?php endif; ?>
                </div>
            </div> 
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
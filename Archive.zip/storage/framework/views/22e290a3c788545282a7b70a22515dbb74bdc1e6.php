<div class="col-md-12">
<table class="table table-bordered table-hover table-striped" width="100%">
    <thead>
        <tr>
            <th class="text-center">No</th>
            <th class="text-center">Pertanyaan</th>
            <th class="text-center">Bobot</th>
            <th class="text-center">Aktif</th>
            <th class="text-center" style="width:80px;">Aksi</th>
        </tr>             
    </thead>
    <tbody>
<?php
    $no=$page+1;
?>
 <?php $__currentLoopData = $instrumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e(($no)); ?></td>
            <td class="text-left"><?php echo e(($v->pertanyaan)); ?></td>
            <td class="text-left"><?php echo e(($v->bobot)); ?></td>
            <td class="text-center">
                <?php echo ($v->flag==1 ? '<span class="label label-success">Aktif</span>' : '<span class="label label-danger">Non Aktif</span>'); ?>

                &nbsp;&nbsp;
                <?php if($v->flag==1): ?>
                    <span class="label label-danger" style="cursor:pointer" onclick="changestatus('<?php echo e($v->id); ?>','0')" data-toggle="tooltip" title="Non Aktifkan" data-placement="top"><i class="fa fa-times"></i></span>
                <?php else: ?>
                    <span class="label label-primary" style="cursor:pointer" onclick="changestatus('<?php echo e($v->id); ?>','1')" data-toggle="tooltip" title="Aktifkan" data-placement="top"><i class="fa fa-check"></i></span>
                <?php endif; ?>
            </td>
            <td class="text-center">
                <a href="javascript:loadform('<?php echo e($v->id); ?>')" style="text-transform:capitalize !important;" class="btn btn-xs btn-success"><i class="fa fa-pencil"></i></a>
                <a href="javascript:hapus('<?php echo e($v->id); ?>')" style="text-transform:capitalize !important;" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
            </td>
        </tr>
<?php
    $no++;
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<div style="text-align:center"><?php echo e($instrumen->links()); ?></div>
</div>
<?php $__env->startSection('title'); ?>
    <title>Kegiatan Fasilitasi - Ensiklomedia</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
             <div id="category" style="margin-top:20px;">
            	<div class="row">
                    
                    <div class="col-md-12">
                        <?php if(Session::has('message')): ?>
                            <div class="alert alert-success">
                                <strong>Sukses!</strong> 
                                <?php echo e(Session::get('message')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-5">
                        
                        <div class="row">
                            <div class="col-md-12" >
                                <h1 class="new-video-title"> Informasi Kegiatan Fasilitasi</h1>
                            </div>
                        </div>
                        <div class="row" id="data">
                            
                            <div class="col-md-4">Lokasi Kegiatan</div>
                            <div class="col-md-8">:&nbsp;&nbsp;<b><?php echo e($fas->provinsi->name); ?></b></div>
                            <div class="col-md-4">Waktu Kegiatan</div>
                            <div class="col-md-8">:&nbsp;&nbsp;<b><?php echo e(date('d-m-Y',strtotime($fas->start_date))); ?></b> s.d. <b><?php echo e(date('d-m-Y',strtotime($fas->end_date))); ?></b></div>
                            
                        </div><!-- // row -->


                        <!-- Loading More Videos -->
                        <div id="loading-more">
                            
                        </div>
                        <!-- // Loading More Videos -->

                    </div>
                    <div class="col-md-5">
                        <div class="row">
                            <div class="col-md-12">
                                <h1 class="new-video-title"><i class="fa fa-files-o"></i>  Peserta Fasilitasi</h1>
                            </div>
                           
                        </div>
                        <div id="form">
                            <table class="table table-bordered table-hover table-striped" width="100%">
                                <thead>
                                    <tr>
                                        <th class="text-center">No</th>
                                        <th class="text-center">Nama Peserta</th>
                                        <th class="text-center">Email</th>
                                        <th class="text-center" style="width:70px;">Cetak Sertifikat</th>
                                    </tr>             
                                </thead>
                                <tbody>
                                    <?php
                                        $no=1;
                                    ?>
                                    <?php $__currentLoopData = $pes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($no++); ?></td>
                                            <td class="text-left"><?php echo e($item->user->profile->name); ?></td>
                                            <td class="text-center"><?php echo e($item->user->email); ?></td>
                                            <td class="text-center">
                                                <a href="<?php echo e(url('cetak/'.$item->user_id.'/'.$item->fasilitasi_id)); ?>" class="btn btn-xs btn-success" target="_blank">
                                                    <i class="fa fa-print"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div><!-- // row -->
            </div>

		
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footscript'); ?>
    <script>
        $(document).ready(function(){
           
        });
        var currentLocation = window.location;
        
    </script>
<?php $__env->stopSection(); ?>

 <style>
    .chosen-container
    {
        width:100% !important;
    }
    th,td
    {
        font-size:12px !important;
        font-weight:200;
    }
    span.label
    {
        font-size:11px !important;
    }
</style>
<?php echo $__env->make('layouts.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
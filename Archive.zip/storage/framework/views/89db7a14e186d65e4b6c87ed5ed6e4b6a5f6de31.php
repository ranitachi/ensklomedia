<?php $__env->startSection('title'); ?>
    <title>Beranda - Ensiklomedia</title>
     <link href="<?php echo e(asset('css/videojs.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div id="all-output" class="col-md-10">
            <h1 class="new-video-title"><i class="fa fa-bolt"></i> Video Favorit</h1>
            <div class="row">
            <?php
            if(isset($video))
            {
                //$no=1;
                shuffle($video);
                $eightdata = array_slice($video, 0, 12);
                foreach($eightdata as $ixk => $vik)
                {
                    $cover="http://ensiklomedia.kemdikbud.go.id/uploads/images/".$vik->image_path;
                    if(File::exists($vik->image_path))
                    {
                        $cv = 'uploadfiles/image/'.$video->image_path;
                        $cover = url($cv);
                        $vv='uploadfiles/video/'.$video->video_path;
                        $vid=url($vv);
                    }
                    else
                    {   
                        //$handle=fopen($cover,'r');
                        $vid="http://ensiklomedia.kemdikbud.go.id/uploads/videos/".$vik->video_path;
                        $cover=$cover;
                        //$fileExists = checkExternalFile($cover);
                        /*if($fileExists==200)
                        {
                            $cover=$cover;
                        }
                        else
                        {
                            $cv='assets/img/no-image-02.png';
                            $cover=url($cv);
                        }*/
                    }
                    $mime = "video/mp4";
                    
                    /*$ffmpeg = FFMpeg\FFMpeg::create(array(
                        'ffmpeg.binaries'  => '/usr/local/Cellar/ffmpeg/3.4.2/bin/ffmpeg',
                        'ffprobe.binaries' => '/usr/local/Cellar/ffmpeg/3.4.2/bin/ffprobe' ,
                        'timeout'          => 3600, // The timeout for the underlying process
                        'ffmpeg.threads'   => 12,
                    ),$logger);*/
                    //$video = $ffmpeg->open($vid);
                    //$media = FFMpeg::open($vid);
                    //$getID3 = new \getID3;
                    //$duration= getDuration($vid);
                    
            ?>
                  <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="video-item">
                        <div class="thumb" style="height:150px;background:url(assets/img/no-image-02.png);background-size:90% 100%;background-position:center">
                        	<div class="hover-efect"></div>
                            <small class="time">10:53</small>
                            <a href="<?php echo e(route('watch', $vik->slug)); ?>" onclick="addhit('<?php echo e($vik->id); ?>')"><img src="<?php echo e($cover); ?>" alt="" style="height:150px;width:100%"></a>
                        </div>
                        <!--<a href="<?php echo e(route('watch', $vik->slug)); ?>">
                            <div class="thumb" id="thumb" style="height:150px;background:url(assets/img/no-image-02.png);background-size:100% 100%;">
                                <video id="example_video_<?php echo e($vik->id); ?>" class="video-js vjs-default-skin vjs-big-play-centered"
                                    controls preload="auto" height="180">
                                    <source src="<?php echo e($vid); ?>" type="<?php echo e($mime); ?>" />
                                </video>
                            </div>
                        </a>-->
                        <div class="video-info">
                            <a href="<?php echo e(route('watch', $vik->slug)); ?>" onclick="addhit('<?php echo e($vik->id); ?>')" class="title"><?php echo e($vik->title); ?></a>
                            <a class="channel-name" href="#"><?php echo e((isset($cat[$vik->category_id]) ? $cat[$vik->category_id]->name : '')); ?><span>
                            <i class="fa fa-check-circle"></i></span></a>
                            <span class="views"><i class="fa fa-eye"></i><?php echo e($vik->hit); ?> views </span>
                            <span class="date"><i class="fa fa-clock-o"></i>5 months ago </span>
                        </div>
                    </div>
                </div>  
            <?php
                }
            }
            ?>
            </div>
     

		</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footscript'); ?>
    <script src="<?php echo e(asset('js/videojs.js')); ?>"></script>
    <script>
        //var lebar=document.getElementById("thumb").offsetWidth;
        //alert(width);
        /*$('video.video-js').each(function(a){
            var id=$(this).attr('id');
            //$('div#'+id).css({'width': width+'px !important'});
            videojs(document.getElementById(id), {
                    width: lebar, 
                    height: 150
                }, function() {
                    this.bigPlayButton.hide();
            });
            // This is functionally the same as the previous example.
        });*/
        function addhit(id)
        {
            $.ajax({
                url : APP_URL+'/video-add-hit/'+id,
                success : function(a){
                }
            });
        }
    </script>
    <style>
        div#example_video_1
        {
            /*width:100% !important;*/
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
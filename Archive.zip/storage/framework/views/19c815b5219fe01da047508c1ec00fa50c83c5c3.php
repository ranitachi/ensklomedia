<div class="row">
    <div class="col-md-12">
        <?php
            $no=1;
        ?>
        <?php $__currentLoopData = $latihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button class="btn btn-xs btn-primary" onclick="lihatsoal('<?php echo e($item->test_id); ?>',<?php echo e($idsaung); ?>)">Soal No. <?php echo e($no); ?></button>
            <?php
                $no++;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div id="detail"></div>
    </div>
</div>
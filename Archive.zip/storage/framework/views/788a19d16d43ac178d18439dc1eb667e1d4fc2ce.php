
<hr>
<div class="row">
    <div class="col-md-12">
        <button class="pull-right btn btn-xs btn-danger" onclick="hapuslatihan(<?php echo e($idsaung); ?>,<?php echo e($id); ?>)">
                <i class="fa fa-trash"></i>&nbsp;Hapus Latihan
        </button>&nbsp;&nbsp;
        <button class="pull-right btn btn-xs btn-success" onclick="latihanform(<?php echo e($idsaung); ?>,<?php echo e($id); ?>)">
            <i class="fa fa-edit"></i>&nbsp;Edit Latihan
        </button>&nbsp;&nbsp;
    </div>
</div>
<ul class="nav nav-tabs" style="margin-top:20px;">
    <li class="active"><a data-toggle="tab" href="#pertanyaann">Pertanyaan</a></li>
<?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($item->flag==1): ?>
        <li><a data-toggle="tab" href="#benar">Jawaban Benar</a></li>
    <?php else: ?>
        <li><a data-toggle="tab" href="#menu<?php echo e($item->id); ?>">Jawaban Lain</a></li>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
</ul>
<div class="tab-content" style="border:1px solid #ccc;border-top:0px;padding:10px;">
    <div id="pertanyaann" class="tab-pane fade in active">
        <?php echo $question; ?>

    </div>
<?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($item->flag==1): ?>
        <div id="benar" class="tab-pane fade">
            <?php echo $item->answer; ?>

        </div>
    <?php else: ?>
        <div id="menu<?php echo e($item->id); ?>" class="tab-pane fade">
            <?php echo $item->answer; ?>

        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</div>
<style>
    .nav>li>a
    {
        padding: 5px 10px !important;
    }
</style>
<video id="example_video_1" controls preload="" style="width:100%;height:auto">
    <source src="{{$vid}}" type="{{$mime}}" />
</video>

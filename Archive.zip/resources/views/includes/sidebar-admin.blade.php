<div class="col-md-2 no-padding-left hidden-sm hidden-xs">
        	<div class="left-sidebar">
            	<div id="sidebar-stick" >
            	<ul class="menu-sidebar">
                	<li><a href="01-home.html"><i class="fa fa-home"></i>Home</a></li>
                	<li><a href="{{URL::to('category')}}"><i class="fa fa-bolt"></i>Category</a></li>
                	<li><a href="14-history.html"><i class="fa fa-clock-o"></i>History</a></li>
                	<li><a href="11-blog.html"><i class="fa fa-file-text"></i>blog</a></li>
                	<li><a href="10-upload.html"><i class="fa fa-upload"></i>upload</a></li>
                </ul>
            	<ul class="menu-sidebar">
                	<li><a href="#"><i class="fa fa-edit"></i>edit profile</a></li>
                	<li><a href="#"><i class="fa fa-sign-out"></i>sing out</a></li>
                </ul>
            	<ul class="menu-sidebar">
                	<li><a href="#"><i class="fa fa-gear"></i>Settings</a></li>
                </ul>
                </div><!-- // sidebar-stick -->
                <div class="clear"></div>
            </div><!-- // left-sidebar -->
        </div>
<template>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                
            </div>
        </div>
    </div>
</template>

<script>
  export default {
    props: ['messages']
  };
</script>